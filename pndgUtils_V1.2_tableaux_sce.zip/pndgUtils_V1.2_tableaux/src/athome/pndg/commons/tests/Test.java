package athome.pndg.commons.tests;

import athome.pndg.commons.styles.exceptions.StylesExceptions;
import athome.pndg.commons.styles.OutilsMiseEnForme;
import athome.pndg.commons.styles.ansi.ANSI_STYLE;

/**
 * Classe de test pour démonstration et recherches.
 */
public class Test {
    public static void main(String[] args) {

        System.out.println("Contenu de l'enum ANSI_STYLE");
        int ctr=0;
        for(int i = 0; i< ANSI_STYLE.values().length; i++){
            ANSI_STYLE ansi = ANSI_STYLE.values()[i];
            System.out.printf(" |%s %02d %s %s",
                    ansi.getCodeAnsi(),
                    i,
                    ANSI_STYLE.RESET.getCodeAnsi(),
                    String.format("%15s",ansi.name())
            );
            ctr++;
            if (ctr % 4 == 0) {
                System.out.println("");
            }
        }

        System.out.println("\n\n Les mise en forme possibles\n");
        String strIdentite = " gilles PENAUD ";

        System.out.println(ANSI_STYLE.UNDERLINE.name()+":"+ OutilsMiseEnForme.stylerSouligneChaine(strIdentite));
        System.out.println(ANSI_STYLE.UNDERLINE_BOLD.name()+":"+OutilsMiseEnForme.stylerSouligneGrasChaine(strIdentite));

        System.out.println(ANSI_STYLE.ITALIC.name()+":"+OutilsMiseEnForme.stylerItalicChaine(strIdentite));
        System.out.println(ANSI_STYLE.BOLD.name()+":"+OutilsMiseEnForme.stylerEnGrasChaine(strIdentite));

        System.out.println(ANSI_STYLE.REVERSE.name()+":"+OutilsMiseEnForme.stylerEnReverseChaine(strIdentite));
        System.out.println(ANSI_STYLE.ENCIRCLED.name()+":"+OutilsMiseEnForme.stylerEntoureChaine(strIdentite));

        System.out.println(ANSI_STYLE.JEANLUC.name()+":"+OutilsMiseEnForme.stylerBarreChaine(strIdentite));

        System.out.println();
        System.out.println(OutilsMiseEnForme.stylerBackground(ANSI_STYLE.BG_CYAN,"coucou",25,true));
        System.out.println(OutilsMiseEnForme.stylerBackground(ANSI_STYLE.BG_CYAN,"Les stagiaires",25,false));
        System.out.println(OutilsMiseEnForme.stylerBackground(ANSI_STYLE.BG_CYAN," du stage LX255 ",25,true));

        System.out.println(OutilsMiseEnForme.centrer("PNDG",24));
        //MEF sur tablo 1 dim
        String[] tablo = {"Militaire","gilles","penaud","adc"};
        try {
            System.out.println(OutilsMiseEnForme.stylerTableauBG1sur2(ANSI_STYLE.BG_CYAN,tablo));
        } catch (StylesExceptions e) {
            throw new RuntimeException(e);
        }
        //MEF sur tablo 2
        String[][] tablo2 = {
                {"PN......","Nom     ","G.."},
                {"gilles  ","penaud  ","dir"},
                {"marc    ","magnum  ","sdir"},
                {"jean luc","bartoldi","pdg"}
        };
        try {
            System.out.println(OutilsMiseEnForme.stylerTableauBG1sur2(ANSI_STYLE.BG_GREEN,tablo2,true));
            System.out.println();

        } catch (StylesExceptions e) {
            throw new RuntimeException(e);
        }


    }




}
