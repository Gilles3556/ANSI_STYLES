package athome.pndg.commons.styles;

import athome.pndg.commons.styles.alignements.TypeAlignement;
import athome.pndg.commons.styles.ansi.ANSI_STYLE;
import athome.pndg.commons.styles.exceptions.StylesExceptions;
import athome.pndg.commons.styles.references.C;

import java.util.Objects;

/**
 * author: PNDG (RAAE at PDI)
 * @version v1.2, 03/2024
 * Classe Utilitaire permettant:
 * - de coloriser (Font et background)
 * - d'appliquer certains styles notamment CENTRER
 */
public final class OutilsMiseEnForme {
    private OutilsMiseEnForme(){}

    private static String stylerChaine(ANSI_STYLE ansi, String str){
        String strw = ansi.getCodeAnsi()+str+ANSI_STYLE.RESET.getCodeAnsi();
        return strw;
    }

    /**
     * Méthode chargée d'appliquer une couleur de Font et background.
     * @param couleurFont: ANSI_STYLE, la couleur de la police
     * @param couleurBackGround: ANSI_STYLE, la couleur du fond
     * @param str:String, la chaine à coloriser
     * @param reverse:boolean, avec effect REVERSE (échange des couleurs FONT et BACKGROUND)
     * @return String, la chaîne mef avec les styles demandés
     */
    public static String stylerFontBackgroundChaine(ANSI_STYLE couleurFont,ANSI_STYLE couleurBackGround, String str,boolean reverse){
        String couleur =couleurFont.getCodeAnsi();
        String bg = couleurBackGround.getCodeAnsi();

        int idx = bg.indexOf('[');
        String bgw =bg.substring(idx+1);
        String strBgcolor = couleur.replace('m',':')+bgw;

        String strNew = strBgcolor+str+ANSI_STYLE.RESET.getCodeAnsi();
        if(reverse){
            strNew+=ANSI_STYLE.REVERSE.getCodeAnsi()+strNew;
        }
        return strNew;
    }


    /**
     * Styler une chaine avec un code couleur.
     * @param ansi: ANSI_STYLE, la couleur
     * @param str: String la chaine à coloriser
     * @return String, la chaîne coloriée
     */
    public static String coloriserChaine(ANSI_STYLE ansi, String str) {
        return stylerChaine(ansi, str);
    }

    /**
     * Mettre en gras une chaine.
     * @param str: String la chaine
     * @return String, la chaîne mise en gras
     */
    public static String stylerEnGrasChaine(String str){
        return stylerChaine(ANSI_STYLE.BOLD, str);
    }

    /**
     * Inverser la couleur d'une chaine, entre font et bg.
     * @param str: String,la chaine
     * @return String, le résultat de la mef
     */
    public static String stylerEnReverseChaine(String str){
        return stylerChaine(ANSI_STYLE.REVERSE, str);
    }

    /**
     * Entourer une chaine.
     * @param str:String, la chaine
     * @return String, le résultat de la mef
     */
    public static String stylerEntoureChaine(String str){
        return stylerChaine(ANSI_STYLE.ENCIRCLED, str);
    }

    /**
     * Souligner une chaine.
     * @param str:String, la chaine
     * @return String, le résultat de la mef
     */
    public static String stylerSouligneChaine(String str) {
        return stylerChaine(ANSI_STYLE.UNDERLINE, str);
    }

    /**
     * Souligner en gras une chaine.
     * @param str:String, la chaine
     * @return String, le résultat de la mef
     */
    public static String stylerSouligneGrasChaine(String str) {
        return stylerChaine(ANSI_STYLE.UNDERLINE_BOLD, str);
    }
    /**
     * Barré une chaine.
     * @param str:String, la chaine
     * @return String, le résultat de la mef
     */
    public static String stylerBarreChaine(String str) {
        return stylerChaine(ANSI_STYLE.JEANLUC, str);
    }
    /**
     * Mettre une chaine en italic.
     * @param str:String, la chaine
     * @return String, le résultat de la mef
     */

    public static String stylerItalicChaine(String str) {
        return stylerChaine(ANSI_STYLE.ITALIC, str);
    }


    /**
     * Méthodec chargée de commencer la mise en forme.
     * @param ansi:ANSI_STYLe, le code ansi
     * @param str:String, la chaine debut
     * @return String, le résultat de la mef
     */
    public static String stylerBackground(ANSI_STYLE ansi,String str,int lg,boolean gauche){
        String strw = ansi.getCodeAnsi()+String.format("%-"+lg+"S",str)+ANSI_STYLE.RESET.getCodeAnsi();
        if(!gauche){
            strw = ansi.getCodeAnsi()+String.format("%"+lg+"S",str)+ANSI_STYLE.RESET.getCodeAnsi();
        }
        return strw;
    }




    /**
     * Méthode chargée d'aligner un texte en fonction du type d'alignement demandé.
     *
     * @param str:String,  le texte à aligner
     * @param largeur:int, largeurMax ds la colonne
     * @param talign:      TypeAlignement
     * @return String
     */
    public static String aligner(String str, int largeur, TypeAlignement talign) {
        String strAlignee = null;

        int lg = str.length();
        if (lg < largeur) {
            lg = largeur;
        }
        switch (talign) {
            case LEFT:
                strAlignee = String.format("%-" + lg + "s", str);
                break;
            case RIGHT:
                strAlignee = String.format("%" + lg + "s", str);
                break;
            case CENTER:
                String strw = "";
                if (str.length() < lg) {
                    strw = str;
                } else {
                    strw = str.substring(0, lg);
                }
                strAlignee = centrer(strw, largeur);
                break;
        }
        return strAlignee;
    }

    /**
     * Méthode chargée de centrer un texte.
     *
     * @param str:String
     * @param size:int   , la dimension
     * @return String
     */
    public static String centrer(String str, int size) {
        String pad = ".";
        StringBuilder sb = new StringBuilder();
        if (str == null || size <= str.length())
            return str;

        for (int i = 0; i < (size - str.length()) / 2; i++) {
            sb.append(pad);
        }
        sb.append(str);

        while (sb.length() < size) {
            sb.append(pad);
        }
        return sb.toString();
    }

    /**
     * Méthode permettant de styliser le background des lignes d'un tableau.
     * @param couleur:ANSI_STYLE, la couleur de fond
     * @param tablo:String[][], le tableau des données
     * @return String
     * @throws StylesExceptions
     */
    public static String stylerTableauBG1sur2(ANSI_STYLE couleur, String[] tablo) throws StylesExceptions {
        if(Objects.isNull(couleur)){
            throw new StylesExceptions(C.MSG_OUTILS_MEF_PARAM_COULEUR_A_NULL);
        }
        if(!isCouleur(couleur)){
            throw new StylesExceptions(C.MSG_OUTILS_MEF_PARAM_COULEUR_INCONNU);
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i <tablo.length ; i++) {
            String strw = tablo[i];
            if((i>0) && ((i-1)%2==0)) {
                strw = stylerChaine(couleur, strw);
            }
            sb.append(strw).append(System.lineSeparator());
        }
        sb.append(System.lineSeparator());

        return sb.toString();
    }

    /**
     * Méthode permettant de vérifier que la couleur est bien une couleur  de ANSI_STYLE.
     * @param couleur:ANSI_STYLE, la couleur
     * @return boolean
     */
    private static boolean isCouleur(ANSI_STYLE couleur) {
        int code =couleur.getIntValue();
        if((code>=30 && code<=37) ||
                (code>=40 && code<=47) ||
                (code>=90 && code<=97)){
            return true;
        }
        return false;
    }

    /**
     * Méthode permettan de tester si la couleur utilisée est bien une couleur de bg.
     * @param couleur:ANSI_STYLE, la couleur de fond
     * @return boolean
     */
    private static boolean isBgCouleur(ANSI_STYLE couleur) {
        int code =couleur.getIntValue();
        if(code>=40 && code<=47){
            return true;
        }
        return false;
    }

    /**
     * Méghode permettant de coliriser les bg des lignes d'un tableau, avec une mef pour l'entête.
     * @param couleur:ANSI_STYLE, la bg couleur
     * @param tablo:String[][], le tableau des données
     * @param entete: boolean, avec entête en ligne 0?
     * @return String: le résultat de la mef
     * @throws StylesExceptions
     */
    public static String stylerTableauBG1sur2(ANSI_STYLE couleur, String[][] tablo,boolean entete) throws StylesExceptions {
        if(Objects.isNull(couleur)){
            throw new StylesExceptions(C.MSG_OUTILS_MEF_PARAM_COULEUR_A_NULL);
        }
        if(!isBgCouleur(couleur)){
            throw new StylesExceptions(C.MSG_OUTILS_MEF_PARAM_COULEUR_INCONNU);
        }
        StringBuilder sb = new StringBuilder();
        for (int y = 0; y <tablo.length ; y++) {
            String strw="";
            for (int x = 0; x < tablo[y].length; x++) {
                strw += tablo[y][x]+" | ";
            }
            if((y>0) && ((y-1)%2==0)) {
                strw = stylerChaine(couleur, strw);
            }

            if(y==0 && entete){
                strw=stylerEnReverseChaine(strw);
                strw+=String.format("%n%25S","-".repeat(27));
            }

            sb.append(strw).append(System.lineSeparator());
        }
        sb.append(System.lineSeparator());

        return sb.toString();
    }
}
