package athome.pndg.commons.styles.references;

public final class C {
    public static final String MSG_OUTILS_MEF_PARAM_COULEUR_A_NULL = "ERR_OutilsMEF: le param couleur vaut NULL";
    public static final String MSG_OUTILS_MEF_PARAM_COULEUR_INCONNU = "ERR_OutilsMEF: le param couleur est inconnu(couleur incorrecte) !";

    private C(){}
}
