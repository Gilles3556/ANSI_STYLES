package athome.pndg.commons.styles.exceptions;

public class StylesExceptions extends Exception {
    public StylesExceptions(String message) {
        super(message);
    }

    public StylesExceptions(String message, Throwable cause) {
        super(message, cause);
    }

    public StylesExceptions(Throwable cause) {
        super(cause);
    }

    public StylesExceptions(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
