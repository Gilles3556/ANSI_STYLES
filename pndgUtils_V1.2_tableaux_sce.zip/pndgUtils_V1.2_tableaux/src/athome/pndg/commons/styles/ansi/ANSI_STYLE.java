package athome.pndg.commons.styles.ansi;

/**
 * enum des codes ANSI permettant de styliser du texte : couleur et qq mef.
 */
public enum ANSI_STYLE {
    RESET("\u001B[0m",0),
    BLACK("\u001B[30m",30),
    RED("\u001B[31m",31),
    GREEN("\u001B[32m",32),
    YELLOW("\u001B[33m",33),
    BLUE("\u001B[34m",34),
    PURPLE("\u001B[35m",35),
    CYAN("\u001B[36m",36),
    WHITE    ("\u001B[37m",37),
    LIGHT_BLACK("\u001B[90m",90),
    LIGHT_RED("\u001B[91m",91),
    LIGHT_GREEN("\u001B[92m",92),
    LIGHT_YELLOW("\u001B[93m",93),
    LIGHT_BLUE("\u001B[94m",94),
    LIGHT_PURPLE("\u001B[95m",95),
    LIGHT_CYAN("\u001B[96m",96),
    LIGHT_GREY("\u001B[97m",97),
    BG_BLACK("\u001B[40m",40),
    BG_RED("\u001B[41m",41),
    BG_GREEN("\u001B[42m",42),
    BG_YELLOW("\u001B[43m",43),
    BG_BLUE("\u001B[44m",44),
    BG_PURPLE("\u001B[45m",45),
    BG_CYAN("\u001B[46m",46),
    BG_GREY("\u001B[47m",47),

    BOLD("\u001B[1m",1),
    REVERSE("\u001B[7m",7),
    ITALIC("\u001B[3m",3),
    ENCIRCLED("\u001B[51m",51),
    JEANLUC("\u001B[9m",9),
    UNDERLINE("\u001B[4m",4),
    UNDERLINE_BOLD("\u001B[21m",21)
    ;

    private String codeAnsi;
    private  int intValue;

    public String getCodeAnsi() {
        return codeAnsi;
    }

    public int getIntValue() {
        return intValue;
    }

    ANSI_STYLE(String codeAnsi,int intv) {

        this.codeAnsi = codeAnsi;
        this.intValue=intv;
    }
}
