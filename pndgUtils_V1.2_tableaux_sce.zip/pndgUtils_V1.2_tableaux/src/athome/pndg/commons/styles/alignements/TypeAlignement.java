package athome.pndg.commons.styles.alignements;

public enum TypeAlignement {
    CENTER,
    LEFT,
    RIGHT;



}
